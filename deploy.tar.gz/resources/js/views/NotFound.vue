<template>
  <div class="min-h-screen flex items-center justify-center bg-gray-100">
    <div class="text-center">
      <h1 class="text-9xl font-bold text-gray-300">404</h1>
      <p class="text-2xl font-semibold text-gray-600 mt-4">الصفحة غير موجودة</p>
      <p class="text-gray-500 mt-2">عذراً، الصفحة التي تبحث عنها غير موجودة</p>
      <router-link to="/" class="btn btn-primary mt-6">العودة للرئيسية</router-link>
    </div>
  </div>
</template>
